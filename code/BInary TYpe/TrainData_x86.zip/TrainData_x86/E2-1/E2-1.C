#define PRICE 30
void main()
{
	int num,total;
	num=10;
	total=num*PRICE;
	printf("total=%d",total);
}
