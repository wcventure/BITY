
void main()
{
	int a=3;
	int b=4;
	int max,min;
	if (a>=b)
	{	
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	
	char hello[5]={'h','e','l','l','o'};

}

