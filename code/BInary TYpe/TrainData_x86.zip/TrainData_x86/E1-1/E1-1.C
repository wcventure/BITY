void main()
{
	char *c="This is a c program";
	printf("%s\n",c);
}
