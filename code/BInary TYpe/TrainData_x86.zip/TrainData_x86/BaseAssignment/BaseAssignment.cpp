
void main()
{
	int a=3;
	int b=4;
	int max,min;
	a=a*b;
	a=a/b;
	if (a>=b)
	{	
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	
	char hello[5]={'h','e','l','l','o'};
	int aa=12;
  	int aaa=-24;
  	char bb='b';
	char cc='3'	;
  	double x=2.2;
  	float y=2.2;
  	long z=19;
 	short zz=1;	
 	x=x/z;
	x=x*z;

}

