#include "stdio.h"
void main()
{
	char c;
	c=getchar();
	putchar(c);
}
