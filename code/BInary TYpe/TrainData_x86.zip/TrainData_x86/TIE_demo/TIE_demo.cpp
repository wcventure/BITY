#include <string.h>

unsigned int foo(char *buf,unsigned int *out)
{
	unsigned int c;
	c = 0;
	if (buf) 
	{
		*out = strlen(buf);
	}
	if (*out) 
	{
		c = *out - 1;
	}
	return c;
}

void main()
{
	unsigned int b=3;
	unsigned int *a=&b;
	foo("abc",a);
}