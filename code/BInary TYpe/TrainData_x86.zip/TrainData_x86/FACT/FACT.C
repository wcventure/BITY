long  fact(int n)
{  long t;
   if(n==0)t=1;
   else t=n*fact(n-1);
   return (t);
}
void main()
{  int m;
   scanf("%d",&m);
   printf("%d!=%ld\n",m,fact(m));
}
