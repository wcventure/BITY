import re

def TransformDwarfFile(path , afterTransformPath):
    NewfileContext = []#用于保存新的类型信息文件，后面用于写文件
    try:
        with open(path, 'r', encoding= 'utf-8') as file:
            #先把文件内容读出来，存在fileContext里面
            fileContext = file.readlines()
            ContextLen = len(fileContext)

            #第一次扫描取出base_type信息
            varCollection = [] #保存base_type信息
            varGlobal = [] #保存全局变量的信息
            for lineNum in range(0, ContextLen):
                #print(fileContext[lineNum], end='')
                matBaseType = re.search("< ?1><(.+)>.*(DW_TAG_base_type).*", fileContext[lineNum])
                matPointerType = re.search("< ?1><(.+)>.*DW_TAG_pointer_type.*", fileContext[lineNum])
                matArraryType = re.search("< ?1><(.+)>.*(DW_TAG_array_type).*", fileContext[lineNum])
                matConstType = re.search("< ?1><(.+)>.*(DW_TAG_const_type).*", fileContext[lineNum])
                if matBaseType:
                    basetypeAdress=matBaseType.groups()[0]
                    if not basetypeAdress[0:2]=='0x':
                        basetypeAdress = '0x' + basetypeAdress
                    basetypeName='uk'
                    for k in range(1,10):
                        if fileContext[lineNum+k].strip()=='' or re.search("<.+><.+>",fileContext[lineNum+k]):
                            break
                        else:
                            #变量的类型
                            matName = re.search('DW_AT_name', fileContext[lineNum + k])
                            if matName:
                                fileContext[lineNum + k] = fileContext[lineNum + k].replace(':','')
                                if '(' in fileContext[lineNum + k] and ')' in fileContext[lineNum + k]:
                                    a=fileContext[lineNum + k].find('(')
                                    b=fileContext[lineNum + k].find(')')
                                    fileContext[lineNum + k] =fileContext[lineNum + k][0:a]+fileContext[lineNum + k][b+1:]
                                if '<' in fileContext[lineNum + k] and '>' in fileContext[lineNum + k]:
                                    a=fileContext[lineNum + k].find('<')
                                    b=fileContext[lineNum + k].find('>')
                                    fileContext[lineNum + k] =fileContext[lineNum + k][0:a]+fileContext[lineNum + k][b+1:]
                                basetypeName = fileContext[lineNum + k].replace('DW_AT_name', '')
                                basetypeName = basetypeName.strip()
                                if '_Bool' in basetypeName:
                                    basetypeName = basetypeName.replace('_Bool','bool')
                                #print(basetypeAdress)
                                #print(basetypeName)
                    varCollection.append({'basetypeAdress': basetypeAdress ,"basetypeName": basetypeName})

                elif matPointerType:
                    typeAdress = matPointerType.groups()[0]
                    if not typeAdress[0:2] == '0x':
                        typeAdress = '0x' + typeAdress
                    # 从basetype中找
                    for k in range(1, 5):
                        if fileContext[lineNum + k].strip() == '' or re.search("<.+><.+>",fileContext[lineNum + k]):
                            break
                        else:
                            matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + k])
                            if matType:
                                flag=1
                                for each in varCollection:
                                    if matType.groups()[0] == each['basetypeAdress']:
                                        typeName = each['basetypeName'] + '*'
                                        varCollection.append({'basetypeAdress': typeAdress, "basetypeName": typeName})
                                        flag=1
                                        break
                                if flag==0:
                                    varCollection.append({'basetypeAdress': typeAdress, "basetypeName": '*'})

                elif matArraryType:
                    typeAdress = matArraryType.groups()[0]
                    if not typeAdress[0:2] == '0x':
                        typeAdress = '0x' + typeAdress
                    # 从basetype中找
                    for k in range(1,5):
                        if fileContext[lineNum+k].strip()=='' or re.search("<.+><.+>",fileContext[lineNum+k]):
                            break
                        else:
                            matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + k])
                            if matType:
                                for each in varCollection:
                                    if matType.groups()[0] == each['basetypeAdress']:
                                        typeName = each['basetypeName'] + '[]'
                                        varCollection.append({'basetypeAdress': typeAdress, "basetypeName": typeName})
                                        break

                elif matConstType:
                    typeAdress = matConstType.groups()[0]
                    if not typeAdress[0:2] == '0x':
                        typeAdress = '0x' + typeAdress
                    # 从basetype中找
                    for k in range(1, 5):
                        if fileContext[lineNum + k].strip() == '' or re.search("<.+><.+>", fileContext[lineNum + k]):
                            break
                        else:
                            matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + k])
                            if matType:
                                for each in varCollection:
                                    if matType.groups()[0] == each['basetypeAdress']:
                                        typeName = 'const ' + each['basetypeName']
                                        varCollection.append({'basetypeAdress': typeAdress, "basetypeName": typeName})
                                        break


            #第二次扫描取出更复杂一点的信息，指针和全局变量
            for lineNum in range(0, ContextLen):
                # print(fileContext[lineNum], end='')
                matPointerType = re.search("< ?1><(.+)>.*DW_TAG_pointer_type.*", fileContext[lineNum])
                matGlobalType = re.search("< ?1><(.+)>.*DW_TAG_variable.*", fileContext[lineNum])
                if matPointerType:
                    typeAdress = matPointerType.groups()[0]
                    if not typeAdress[0:2] == '0x':
                        typeAdress = '0x' + typeAdress
                    # 从basetype中找
                    for k in range(1, 5):
                        if fileContext[lineNum + k].strip() == '' or re.search("<.+><.+>", fileContext[lineNum + k]):
                            break
                        else:
                            matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + k])
                            flag = 0
                            if matType:
                                for each in varCollection:
                                    if matType.groups()[0] == each['basetypeAdress']:
                                        typeName = each['basetypeName'] + '*'
                                        varCollection.append({'basetypeAdress': typeAdress, "basetypeName": typeName})
                                        flag = 1
                                        break
                                if flag == 0:
                                    varCollection.append({'basetypeAdress': typeAdress, "basetypeName": 'unknown*'})

                elif matGlobalType:
                    globaltypeAdress = matGlobalType.groups()[0]
                    globaltypeName = 'uk'
                    globaltypeCode = 'uk'
                    for k in range(1, 10):
                        if fileContext[lineNum + k].strip() == '' or re.search("<.+><.+>", fileContext[lineNum + k]):
                            break
                        else:
                            # 变量的类型
                            matName = re.search('DW_AT_name', fileContext[lineNum + k])
                            matTypeCode = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + k])
                            if matName:
                                fileContext[lineNum + k] = fileContext[lineNum + k].replace(':', '')
                                if '(' in fileContext[lineNum + k] and ')' in fileContext[lineNum + k]:
                                    a = fileContext[lineNum + k].find('(')
                                    b = fileContext[lineNum + k].find(')')
                                    fileContext[lineNum + k] = fileContext[lineNum + k][0:a] + fileContext[lineNum + k][b + 1:]
                                if '<' in fileContext[lineNum + k] and '>' in fileContext[lineNum + k]:
                                    a = fileContext[lineNum + k].find('<')
                                    b = fileContext[lineNum + k].find('>')
                                    fileContext[lineNum + k] = fileContext[lineNum + k][0:a] + fileContext[lineNum + k][b + 1:]
                                globaltypeName = fileContext[lineNum + k].replace('DW_AT_name', '')
                                globaltypeName = globaltypeName.strip()
                            elif matTypeCode:
                                globaltypeCode = matTypeCode.groups()[0]
                                # print(globaltypeCode)
                    varGlobal.append({'globaltypeCode': globaltypeCode, "globaltypeName": globaltypeName})


            #第三次扫描取出函数信息(已改善，紧接着第二次后面)
            for lineNum in range(0, ContextLen):
                #print(fileContext[lineNum], end='')
                matSubProgram = re.search("< ?1><.+>.*DW_TAG_subprogram.*", fileContext[lineNum])
                if matSubProgram:
                    i = 1
                    SubProgramName='uk'
                    SubProgramType='uk'
                    varList=[]#后面用于保存该函数的变量信息
                    #此处找出该函数的信息
                    while True:
                        if lineNum+i == ContextLen -1:
                            break
                        if fileContext[lineNum+i].strip()=='' or re.search("<.+><.+>",fileContext[lineNum+i]):#跳出循环的条件
                            break
                        else:
                            #函数名
                            matName = re.search('DW_AT_name', fileContext[lineNum + i])
                            matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + i])
                            if matName:
                                fileContext[lineNum + i] = fileContext[lineNum + i].replace(':', '')
                                if '(' in fileContext[lineNum + i] and ')' in fileContext[lineNum + i]:
                                    a = fileContext[lineNum + i].find('(')
                                    b = fileContext[lineNum + i].find(')')
                                    fileContext[lineNum + i] = fileContext[lineNum + i][0:a] + fileContext[lineNum+i][b+1:]
                                if '<' in fileContext[lineNum + i] and '>' in fileContext[lineNum + i]:
                                    a = fileContext[lineNum + i].find('<')
                                    b = fileContext[lineNum + i].find('>')
                                    fileContext[lineNum + i] = fileContext[lineNum + i][0:a] + fileContext[lineNum+i][b+1:]
                                SubProgramName = fileContext[lineNum + i].replace('DW_AT_name', '')
                                SubProgramName = SubProgramName.strip()
                            #函数的返回类型
                            elif matType:
                                #从varCollection中找
                                for each in varCollection:
                                    if matType.groups()[0]==each['basetypeAdress']:
                                        SubProgramType = each['basetypeName']
                            #循环过程中在改变的量
                            i = i + 1

                    #print(SubProgramName)
                    #print(SubProgramType)

                    #此处找的是DW_TAG_formal_parameter和DW_TAG_variable
                    while True:
                        #跳出循环的条件
                        if lineNum+i == ContextLen -1:
                            break
                        elif fileContext[lineNum + i].strip() == '' or re.search("< ?1><.+>", fileContext[lineNum + i]):
                            break

                        #查找DW_TAG_formal_parameter和DW_TAG_variable
                        matParameter = re.search("< ?2><.+>.*DW_TAG_formal_parameter.*", fileContext[lineNum + i])
                        matVariable  = re.search("< ?2><.+>.*DW_TAG_variable.*", fileContext[lineNum + i])

                        if matParameter or matVariable:
                            varName='uk'
                            varType='uk'
                            for k in range(1,10):
                                if fileContext[lineNum + i + k].strip() == '' or re.search("<.+><.+>", fileContext[lineNum + i + k]):
                                    i = i + k - 1
                                    break
                                else:
                                    #变量名字
                                    matName = re.search('DW_AT_name', fileContext[lineNum + i + k])
                                    matType = re.search('DW_AT_type.+<(\w+)>', fileContext[lineNum + i + k])
                                    if matName:
                                        fileContext[lineNum + i + k] = fileContext[lineNum + i + k].replace(':', '')
                                        if '(' in fileContext[lineNum + i + k] and ')' in fileContext[lineNum + i + k]:
                                            a = fileContext[lineNum + i + k].find('(')
                                            b = fileContext[lineNum + i + k].find(')')
                                            fileContext[lineNum + i + k] = fileContext[lineNum + i + k][0:a] + fileContext[lineNum + i + k][b + 1:]
                                        if '<' in fileContext[lineNum + i + k] and '>' in fileContext[lineNum + i + k]:
                                            a = fileContext[lineNum + i + k].find('<')
                                            b = fileContext[lineNum + i + k].find('>')
                                            fileContext[lineNum + i + k] = fileContext[lineNum + i + k][0:a] + fileContext[lineNum + i + k][b + 1:]
                                        varName = fileContext[lineNum + i + k].replace('DW_AT_name', '')
                                        varName = varName.strip()
                                        #print(varName)
                                    #变量类型
                                    elif matType:
                                        # 从varCollection中找
                                        for each in varCollection:
                                            if matType.groups()[0] == each['basetypeAdress']:
                                                varType = each['basetypeName']
                                                break
                                        #print(varType)
                            if matParameter:
                                varList.append({'varName':varName, 'varType':varType, 'PorV':'parameter'})
                            elif matVariable:
                                varList.append({'varName':varName, 'varType':varType, 'PorV':'variable'})
                        # 循环过程中在改变的量
                        i = i + 1


                    #输出结果
                    #print('function: ',end='')
                    #print(SubProgramType,end=' ')
                    #print(SubProgramName, end='()\n')

                    NewfileContext.append('function: '+ SubProgramName + '()\n')

                    if not varList==[]:
                        for each in varList:
                            if each['varName']!='uk' and each['varType']!='uk':
                                #print(each['PorV'], end=': ')
                                #print(each['varType'], end=' ')
                                #print(each['varName'], end=';\n')
                                if '[]'in each['varType']:
                                    NewfileContext.append(each['PorV'] + ': ' + each['varType'].replace('[]','') + ' ' + each['varName'] + '[];\n')
                                else:
                                    NewfileContext.append(each['PorV']+': '+each['varType']+' '+each['varName']+';\n')
                    #print("----------")
                    NewfileContext.append("----------\n")
            #输出全局变量
            if not varGlobal == []:
                for eachGvar in varGlobal:
                    for each in varCollection:
                        if eachGvar['globaltypeCode'] == each['basetypeAdress']:
                            #print('variable: ', end = '')
                            #print(each['basetypeName'], end = ' ')
                            #print(eachGvar['globaltypeName'], end=';\n')
                            #print('(global variable)')
                            #print("----------")
                            NewfileContext.append('variable: '+each['basetypeName']+' '+eachGvar['globaltypeName']+';\n')
                            NewfileContext.append('(global variable)\n')
                            NewfileContext.append("----------\n")
    except IOError as err:
        print('File error:' + str(err))

    try:
        if not NewfileContext==[]:
            with open(afterTransformPath, 'w') as file:
                for eachline in NewfileContext:
                    file.write(eachline)
    except IOError as err:
        print('File error:' + str(err))


#path = 'SaveData/dwarf.txt'
#TransformDwarfFile(path,'SaveData/dwraf_output.txt')

path = "gcc-32-O0-diffutils-cmp_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-cmp.txt')
path = "gcc-32-O0-diffutils-diff_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-diff.txt')
path = "gcc-32-O0-diffutils-diff3_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-diff3.txt')
path = "gcc-32-O0-diffutils-sdiff_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-sdiff.txt')
path = "gcc-32-O0-findutils-find_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-find.txt')
path = "gcc-32-O0-findutils-frcode_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-frcode.txt')
path = "gcc-32-O0-findutils-locate_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-locate.txt')
path = "gcc-32-O0-findutils-xargs_dwarf.txt"
TransformDwarfFile(path,'gcc-32-O0-diffutils-xargs.txt')
