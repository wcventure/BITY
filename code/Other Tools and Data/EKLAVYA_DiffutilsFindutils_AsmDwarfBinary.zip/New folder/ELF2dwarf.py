import os

os.system("objdump --dwarf gcc-32-O0-diffutils-cmp >gcc-32-O0-diffutils-cmp_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-diffutils-diff >gcc-32-O0-diffutils-diff_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-diffutils-diff3 >gcc-32-O0-diffutils-diff3_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-diffutils-sdiff >gcc-32-O0-diffutils-sdiff_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-findutils-find >gcc-32-O0-findutils-find_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-findutils-frcode >gcc-32-O0-findutils-frcode_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-findutils-locate >gcc-32-O0-findutils-locate_dwarf.txt")
os.system("objdump --dwarf gcc-32-O0-findutils-xargs >gcc-32-O0-findutils-xargs_dwarf.txt")