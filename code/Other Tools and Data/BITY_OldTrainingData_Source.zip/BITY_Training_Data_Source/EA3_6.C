#include <stdio.h>

int main(int argc, char *argv[])
{
	double x,y;
	x=1111111111111.111111111;
	y=2222222222222.222222222;
	printf("%f\n",x+y);
	return 0;
}
