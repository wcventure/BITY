char * memset (char *dst,char value,unsigned int count)
       {
       char *start = dst;

       while (count--)
           *dst++ = value;
       return(start);
       }
	   
int main()
{
	char* dst;
	char src;
	memset(dst,src,1);
}