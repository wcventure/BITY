
#include<ctype.h>

int _memicmp (char *first, char * last, unsigned count)
               {
               if (!count)
                       return(0);
               while (--count && tolower(*first) == tolower(*last))
                       {
                       first++;
                       last++;
                       }
              return(tolower(*first) - tolower(*last));
               }

int main()
{
	char* dst;
	char* src;
	_memicmp(dst,src,1);
}