#include <stdio.h>

void func(int n, double s, double t)
{

	for (n=1;n<=20;n++)
	{
		t=t*n;s=s+t;
	}
	printf("%20.0f\n",s);
}


int main(int argc, char *argv[])
{
	int n;
	double s=0,t=1;
	func(n,s,t);
	return 0;
}