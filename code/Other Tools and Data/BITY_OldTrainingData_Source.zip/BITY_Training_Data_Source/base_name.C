#include <stdio.h>
#include <stdlib.h>

void basename (char *string, char *suffix, bool use_nuls)
{
  char *name = string;

  if (suffix && use_nuls)
	 free (name);
}

int main(int argc, char *argv[])
{
	basename("asdf","asdf",true);
}