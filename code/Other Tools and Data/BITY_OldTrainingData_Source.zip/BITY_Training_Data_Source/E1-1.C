#include <stdio.h>
void func(char* c)
{
	
	printf("%s\n",c);
}

int main(int argc, char *argv[])
{
	char *c="This is a c program";
	func(c);
	return 0;
}