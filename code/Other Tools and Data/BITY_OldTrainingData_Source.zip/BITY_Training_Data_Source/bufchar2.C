#include <stdio.h>


void func(char a[])
{  
	for (int i=0;i<10;i++)
		a[i]=0;
}

int main(int argc, char *argv[])
{
	char a[10];
	func(a);
	return 0;
}