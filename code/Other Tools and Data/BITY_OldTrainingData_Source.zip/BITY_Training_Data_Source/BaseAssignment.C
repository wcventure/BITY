
void func(int a, int b, char bb ,char cc ,double x, float y, long z, short zz)
{
	a=3;
	b=4;
	int max,min;
	a=a*b;
	a=a/b;
	if (a>=b)
	{	
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	
	char hello[5]={'h','e','l','l','o'};
	int aa=12;
  	int aaa=-24;
  	bb='b';
	cc='3'	;
  	x=2.2;
  	y=2.2;
  	z=19;
 	zz=1;	
 	x=x/z;
	x=x*z;

}

int main(int argc, char *argv[])
{
	func(1, 2, 2, 'a', 3.3, 5.5, 7, 8);
	return 0;
}
