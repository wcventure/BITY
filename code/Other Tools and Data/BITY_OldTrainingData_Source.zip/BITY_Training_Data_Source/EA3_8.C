#include "stdio.h"
int main(int argc, char *argv[])
{
	char c;
	c=getchar();
	putchar(c);
	return 0;
}
