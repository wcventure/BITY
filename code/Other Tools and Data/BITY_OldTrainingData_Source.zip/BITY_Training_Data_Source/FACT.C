#include <stdio.h>
long  fact(int n,long t)
{  
   if(n==0)t=1;
   else t=n*fact(n-1,t);
   return (t);
}
int main()
{  int m;
	long t;
   scanf("%d",&m);
   printf("%d!=%ld\n",m,fact(m,t));
   return 0;
}
