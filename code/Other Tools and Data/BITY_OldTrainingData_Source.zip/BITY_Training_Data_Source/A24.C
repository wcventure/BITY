#include <math.h>
#include <stdio.h>

void func(int x, int y)
{  int r,q,w;
   r=x;q=0;w=y;
   while (w<=x) w*=2;
   while (w!=y)
   {  
		q*=2;
		w=floor(w/2);
		if (w<=r) {
			r-=w;
			q++;
		}
   }
   printf("%d,%d\n",q,r);
}

int main(int argc, char *argv[])
{
	func(2, 3);
	return 0;
}