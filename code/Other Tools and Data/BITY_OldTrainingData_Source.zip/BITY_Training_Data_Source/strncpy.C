char * strncpy (char *dest,char * source,unsigned count)
       {
         char *start = dest;

         while (count && (*dest++ = *source++))
             count--;
         if (count)
             while (--count)
                 *dest++ = '\0';
         return(start);
       }

int main()
{
	char* dst;
	char* src;
	strncpy(dst,src,1);
}