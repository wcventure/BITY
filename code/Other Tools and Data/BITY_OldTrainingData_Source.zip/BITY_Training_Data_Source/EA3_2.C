#include <stdio.h>

void func(unsigned int a, int b)
{
	printf("a=%d,%o,%x,%u\n",a,a,a,a);
	printf("b=%d,%o,%x,%u\n",b,b,b,b);
}

int main(int argc, char *argv[])
{
	unsigned int a=65535;
	int b=-2;
	func(a, b);
	return 0;
}