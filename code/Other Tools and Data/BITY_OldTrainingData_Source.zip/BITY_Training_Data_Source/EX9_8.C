int strspn (unsigned char *string, unsigned char *control)
       {
               unsigned char map[32];
               int count;

               for (count = 0; count < 32; count++)
                       map[count] = 0;
               while (*control)
               {
                       map[*control >> 3] |= (1 << (*control & 7));
                       control++;
               }
               if (*string)
               {
                       while (map[*string >> 3] & (1 << (*string & 7)))
                       {
                               count++;
                               string++;
                       }
                       return(count);
               }
               return(0);
       }

int main()
{
	unsigned char* dst;
	unsigned char* src;
	strspn(dst,src);
}