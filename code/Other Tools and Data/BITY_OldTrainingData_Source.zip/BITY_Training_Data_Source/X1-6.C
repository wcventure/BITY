#include <stdio.h>
#include <math.h>

int max(int x,int y,int z)
{
	int s;
	if (x>y) s=x;
	else s=y;
	if (s<z) s=z;
	return(s);
}

int main(int argc, char *argv[])
{
	int a,b,c,m;
	scanf("%d,%d,%d",&a,&b,&c);
	m=max(a,b,c);
	printf("max=%d\n",m);
	return 0;
}
	
