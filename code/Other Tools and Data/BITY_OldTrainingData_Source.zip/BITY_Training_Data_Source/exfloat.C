float exdouble(float a,float b)
{
	float c,d,e,f;
	c=a+b;
	d=a-b;
	e=a*b;
	d=a/b;
}

int main()
{
	float a;
	float b;
	exdouble(a,b);
	return 0;
}