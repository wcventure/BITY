/* The official name of this program (e.g., no `g' prefix).  */
#define PROGRAM_NAME "cksum"

#define AUTHORS proper_name ("Q. Frank Xia")

#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>


# define BIT(x)	((uint_fast32_t) 1 << (x))
# define SBIT	BIT (31)
# define BUFLEN 199

bool cksum (const char *file, bool print_name)
{
  unsigned char buf[BUFLEN];
  uint_fast32_t crc = 0;
  uintmax_t length = 0;
  size_t bytes_read;
  FILE *fp;
  char length_buf[100];
  char const *hp;
  bool have_read_stdin;

  if (file)
    {
      fp = stdin;
      have_read_stdin = true;

    }
  else
    {
      fp = fopen (file, "rb" );
      if (fp == NULL)
        {
          //error (0, errno, "%s", file);
          return false;
        }
    }

  while ((bytes_read = fread (buf, 1, BUFLEN, fp)) > 0)
    {
      unsigned char *cp = buf;

      if (length + bytes_read < length)
        //error (EXIT_FAILURE, 0, _("%s: file too long"), file);
      length += bytes_read;
      while (bytes_read--)
        crc = (crc << 8);
      if (feof (fp))
        break;
    }

}

int main(int argc, char *argv[])
{
	cksum("asdf", true);
	return 0;
}