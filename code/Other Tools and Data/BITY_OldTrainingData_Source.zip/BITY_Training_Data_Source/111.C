void func(int a, int b)
{
	a=3;
	b=4;
	int max,min;
	if (a>=b)
	{	
		max=a;
		min=b;
	}
	else
	{
		max=b;
		min=a;
	}
	
	char hello[5]={'h','e','l','l','o'};
}

int main(int argc, char *argv[])
{
	func(2, 3);
	return 0;
}