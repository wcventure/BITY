void exptr(int* a,int* b)
{
	int* c,*d,*e,*f;
	*c=*a+*b;
	*d=*a-*b;
	*e=*a * (*b);
	*f=*a/(*b);
}

int main()
{
	int* a;
	int* b;
	exptr(a,b);
	return 0;
}