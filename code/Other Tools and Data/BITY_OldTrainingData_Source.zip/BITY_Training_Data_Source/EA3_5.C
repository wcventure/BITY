#include <stdio.h>
int main(int argc, char *argv[])
{
	float x,y;
	x=111111.111;
	y=222222.222;
	printf("%f\n",x+y);
	return 0;
}
