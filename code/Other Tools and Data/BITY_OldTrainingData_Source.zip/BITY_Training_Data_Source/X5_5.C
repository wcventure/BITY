#include <stdio.h>

void func(int k ,double s)
{
	for (k=1;k<=100;k++) s=s+k;
	for (k=1;k<=50;k++) s=s+k*k;
	for (k=1;k<=10;k++) s=s+1/(double)k;
	printf("%f\n",s);
}


int main(int argc, char *argv[])
{
	int k;
	double s=0;
	func(k,s);
	return 0;
}