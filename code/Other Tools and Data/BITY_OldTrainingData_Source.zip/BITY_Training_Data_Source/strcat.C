 char * strcat (char * dst, char * src)
 {
	char * cp = dst;
	while( *cp )
		++cp;           /* Find end of dst */
	while( *cp++ = *src++ );               /* Copy src to end of dst */
		return( dst );
}

int main()
{
	char* dst;
	char* src;
	strcat(dst,src);
}