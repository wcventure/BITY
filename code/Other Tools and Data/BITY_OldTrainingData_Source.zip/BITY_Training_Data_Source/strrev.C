char * _strrev (char *string)
             {
             char *start = string;
             char *left = string;
             char ch;

             while (*string++)
                     ;
             string -= 2;
             while (left < string)
                     {
                     ch = *left;
                     *left++ = *string;
                     *string-- = ch;
                     }
             return(start);
             }

int main()
{
	char* dst;
	char* src;
	_strrev(dst);
}