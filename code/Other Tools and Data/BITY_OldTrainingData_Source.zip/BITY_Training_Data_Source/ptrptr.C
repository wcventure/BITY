#include<stdio.h>

void func(int k,int *p,int **pp){

	k=8;
	p=&k;
	pp=&p;
	printf("x=%d\n",**pp);//*pp=p,**pp=k=8
}

int main(int argc, char *argv[])
{
	int k,*p,**pp;
	func(k, p,pp);
	return 0;
}