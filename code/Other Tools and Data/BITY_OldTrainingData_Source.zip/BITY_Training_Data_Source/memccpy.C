char * _memccpy (char *dest,char * src, char _c,unsigned int count)
             {
             while (count && (*dest++ = *src++) != _c)
                     count--;

             return(count ? dest : 0);
             }

int main()
{
	char* dst;
	char* src;
	_memccpy(dst,src , 'a',1);
}