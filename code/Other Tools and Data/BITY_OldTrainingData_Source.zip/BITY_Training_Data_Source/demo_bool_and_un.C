void func(bool x,bool y)
{
	unsigned int a=1213;
	unsigned int b=(a+123-321)*2;
	unsigned int c=b/2;
	
	if (x)
		x=false;
	else if(y)
		y=true;

}

int main(int argc, char *argv[])
{
	bool x=true;
	bool y=false;

	func(x,y);
	return 0;
}