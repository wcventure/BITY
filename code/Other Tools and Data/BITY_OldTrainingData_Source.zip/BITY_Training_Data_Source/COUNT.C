/*count.c--using standard I/O */
#include <stdio.h>
int func(int ch,FILE *fp, long count,int argc, char *argv[])
{
    
    if (argc!=2)
    {
      printf("Usage:%s filename\n",argv[0]);
          return 0;
    }
    if ((fp=fopen(argv[1],"r"))==NULL)
    {
      printf("Can't open %s\n",argv[1]);
          return 0;
    }
    while ((ch=getc(fp))!=EOF)
    {
      putc(ch,stdout);
      count++;
    }
    fclose(fp);
    printf("File %s has %ld characters\n",argv[1],count);
    return 0;
}

int main(int argc, char *argv[])
{
    int ch;
    FILE *fp;
    long count=0;
	func(ch,fp,count,argc,argv);
	return 0;
}