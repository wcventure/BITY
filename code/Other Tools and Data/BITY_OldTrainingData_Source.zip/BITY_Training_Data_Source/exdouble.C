double exdouble(double a,double b)
{
	double c,d,e,f;
	c=a+b;
	d=a-b;
	e=a*b;
	d=a/b;
}

int main()
{
	double a;
	double b;
	exdouble(a,b);
	return 0;
}