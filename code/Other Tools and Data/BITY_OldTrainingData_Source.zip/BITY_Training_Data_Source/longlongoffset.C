long long int offset (long long a , long long b)
{
	return a + b;
}

int main(){
	long long int x = 65530;
	long long int y = 65531;

	offset(x,y);
	return 0;

}

