char * strncat (char *front,char *back,unsigned count)
       {
           char *start = front;

           while (*front++)
               ;
           front--;
           while (count--)
               if (!(*front++ = *back++))
                   return(start);
           *front = '\0';
           return(start);
       }

int main()
{
	char* dst;
	char* src;
	strncat(dst,src,1);
}