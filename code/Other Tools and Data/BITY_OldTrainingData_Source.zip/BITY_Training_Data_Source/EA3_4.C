int strlen (const char * str)
       {
           int length = 0;

           while( *str++ )
                   ++length;

           return( length );
       }
   
int main(int argc, char *argv[])
{
	strlen("2324234");
	return 0;
}