char *strchr (char *string,char chr)
{
    while (*string && *string != chr)
		string++;
    if (*string == chr)
        return(string);
    return((char *)0);
}

int main()
{
	char* dst;
	char src;
	strchr(dst,src);
}