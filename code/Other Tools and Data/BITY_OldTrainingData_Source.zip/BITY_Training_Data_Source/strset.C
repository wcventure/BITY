char * _strset (char *string, char val)
             {
             char *start = string;

             while (*string)
                     *string++ = val;
             return(start);
             }

int main()
{
	char* dst;
	char src;
	 _strset(dst,src);
}