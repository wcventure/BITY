char * memchr (char *buf,int chr,unsigned cnt)
       {
               while (cnt && *buf++ != chr)
                       cnt--;
               return(cnt ? --buf : 0);
       }

int main()
{
	char* dst;
	char* src;
	memchr(dst,1,1);
}