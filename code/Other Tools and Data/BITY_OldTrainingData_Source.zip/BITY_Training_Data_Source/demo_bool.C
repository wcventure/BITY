#include <stdio.h>
int func(bool success)
{
	if (!success)
	{
    	bool a,b,c,d,e;
		a = true;
		b = false;
		c = 0;
		d = 1;
		e = 5;
		printf("bool = %d\n",sizeof(a));
		printf("a = %d;b = %d;c = %d;d = %d;e = %d\n",a,b,c,d,e);
	}
	return 0;
}

int main(int argc, char *argv[])
{
	bool success = false;  // <! true or false
	func(success);
	return 0;
}