          int strcmp ( const char *str1, const char *str2 )
          {
                  const unsigned char *src1 = (const unsigned char *)str1;
                  const unsigned char *src2 = (const unsigned char *)str2;
                  int ret = 0 ;

                  while( ! (ret = *src1 - *src2) && *src2)
                          ++src1, ++src2;

                  if ( ret < 0 )
                          ret = -1 ;
                  else if ( ret > 0 )
                          ret = 1 ;

                  return( ret );
          }

int main()
{
	char* dst;
	char* src;
	strcmp(dst,src);
}