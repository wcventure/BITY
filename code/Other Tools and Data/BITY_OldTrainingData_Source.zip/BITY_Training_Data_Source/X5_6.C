#include <stdio.h>

void func(int m,int a,int b,int c)
{
	for (m=100;m<1000;m++)
	{
		a=m/100;
		b=(m-a*100)/10;
		c=m-a*100-b*10;
		if (m==a*a*a+b*b*b+c*c*c)
		printf("%d\n",m);
   }
}


int main(int argc, char *argv[])
{
	int m,a,b,c;
	func(m,a,b,c);
	return 0;
}