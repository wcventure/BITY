       char * _strnset (char * string,char val,unsigned int count)

             {
             char *start = string;

             while (count-- && *string)
                     *string++ = val;
             return(start);
             }

int main()
{
	char* dst;
	char src;
	_strnset(dst,src,1);
}