#include <stdio.h>
int func(char AString[])
{  
   printf("%s,%s\n",(void *)AString,AString);
   return 0;
}

int main(int argc, char *argv[])
{
	char AString[]="String";
	func(AString);
	return 0;
}