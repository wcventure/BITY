/* day_mon4.c - - uses pointer notation */
#include <stdio.h>
#define MONTHS 12
int days[MONTHS]={31,28,31,30,31,30,31,31,30,31,30,31};
int func(int index)
{
    extern int days[];    /* optional declaration */
    for (index=0;index<MONTHS;index++)
       printf("Month %2d has %d days.\n",index+1,*(days+index));
    return 0;
}

int main(int argc, char *argv[])
{
	int a;
	func(a);
	return 0;
}