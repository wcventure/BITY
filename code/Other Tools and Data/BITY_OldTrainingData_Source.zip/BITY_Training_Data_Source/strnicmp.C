
#include<ctype.h>
int  _strncmpi (char *first, char *last, unsigned int count)
             {
            int f,l;
             int result = 0;
             if (count) {
                     do      {
                             f = tolower(*first);
                             l = tolower(*last);
                             first++;
                             last++;
                             } while (--count && f && l && f == l);
                     result = f - l;
                     }
             return(result);
             }


int main()
{
	char* dst;
	char* src;
	_strncmpi(dst,src,1);
}