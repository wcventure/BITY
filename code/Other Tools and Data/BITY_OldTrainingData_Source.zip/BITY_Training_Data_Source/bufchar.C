#include <stdio.h>


void func(char a[])
{  
	a[0]=1;
	a[1]=2;
}

int main(int argc, char *argv[])
{
	char a[10];
	func(a);
	return 0;
}