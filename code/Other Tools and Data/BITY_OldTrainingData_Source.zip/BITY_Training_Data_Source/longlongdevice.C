long long int device (long long a , long long b)
{
	return a + b;
}

int main(){
	long long int x = 65530;
	long long int y = 65531;

	device(x,y);
	return 0;

}

