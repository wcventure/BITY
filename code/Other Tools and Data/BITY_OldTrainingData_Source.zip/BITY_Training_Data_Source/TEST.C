
#include <stdio.h>

char xx[100][11] ;
int yy[10] ;


int ReadDat(FILE *fp,int i)
{
  if((fp = fopen("TEST.IN", "r")) == NULL) return 1 ;
  for(i = 0 ; i < 100 ; i++) {
    if(fgets(xx[i], 11 , fp) == NULL) return 1 ;
    xx[i][10] = '\0' ;
  }
  fclose(fp) ;
  return 0 ;
}

void WriteDat(FILE *fp,int i)
{
  fp = fopen("TEST.OUT", "w") ;
  for(i = 0 ; i < 10 ; i++) {
    fprintf(fp, "%d\n", yy[i]) ;
    printf("��%d���˵�ѡƱ��=%d\n", i + 1, yy[i]) ;
  }
  fclose(fp) ;
}

void CountRs()
{
}

int main()
{
  int i ;
  FILE *fp ;

  for(i = 0 ; i < 10 ; i++) yy[i] = 0 ;
  if(ReadDat(fp,i)) {
    printf("ѡƱ�����ļ�XP.IN���ܴ�!\007\n") ;
    return 0;
  }
  CountRs() ;
  
  WriteDat(fp,i) ;
  return 0;
}
