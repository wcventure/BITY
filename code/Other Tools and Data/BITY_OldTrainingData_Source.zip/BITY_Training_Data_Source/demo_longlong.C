long long longlong (long long a, long long b, long long c, double d)
{
	c=a+b;
	b=a/c;
	d=c+b;
	return b;
}

int main()
{
	long long a; 
	long long b; 
	long long c; 
	double d;
	longlong (a,b,c,d);
	return 0;
}