#include <stdlib.h>
#include <string.h>


void emit_ancillary_info(char* lc_messages)
{
	if (lc_messages)
		strncmp(lc_messages,"en_",3);
}

int main(int argc, char *argv[])
{
	emit_ancillary_info("123214");
	return 0;
}