#include <stdio.h>

void func(int a, int n, int i, long s,long t)

{

	for (i=1;i<=n;i++)
	{
		t=t*10+a;
		s=s+t;
	}
	printf("%ld\n",s);
}



int main(int argc, char *argv[])
{
	int a,n,i;
	long s=0,t=0;
	func(a,n,i,s,t);
	return 0;
}