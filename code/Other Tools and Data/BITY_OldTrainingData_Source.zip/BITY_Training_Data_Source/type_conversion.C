
int double2int(double a)
{
	int b=a;
	return b;
}

long double2long(double a)
{
	long b=a;
	return b;
}

short double2short(double a)
{
	short b=a;
	return b;
}

float double2float(double a)
{
	float b=a;
	return b;
}

double int2double(int a)
{
	double b=a;
	return b;
}

float int2float(int a)
{
	float b=a;
	return b;
}

short int2short(int a)
{
	short b=a;
	return b;
}

long int2long(int a)
{
	long b=a;
	return b;
}

int float2int(float a)
{
	int b=a;
	return b;
}

double float2double(float a)
{
	double b=a;
	return b;
}

long float2long(float a)
{
	long b=a;
	return b;
}

short float2short(float a) 
{
	short b=a;
	return b;
}

int short2int(short a)
{
	int b=a;
	return b;
}

float short2float(short a)
{
	float b=a;
	return b;
}

double short2double(short a)
{
	double b=a;
	return b;
}

long short2long(short a)
{
	long b=a;
	return b;
}

int main(int argc, char *argv[])
{
	double2int(1.0);
	double2float(1.0);
	double2long(1.0);
	double2short(1.0);
	int2double(3);
	int2float(3);
	int2long(3);
	int2short(3);
	float2double(5.0);
	float2int(5.0);
	float2long(5.0);
	float2short(5.0);
	short2double(9);
	short2float(9);
	short2int(9);
	short2long(9);
	return 0;
}