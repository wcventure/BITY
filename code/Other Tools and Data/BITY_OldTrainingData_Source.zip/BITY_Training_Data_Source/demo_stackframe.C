
int a=0;
char b='b';



int bar(int a,int b)
{
	int c=a+b;
	return c;
}

void newHeap()
{
	int *a=new int[10];
	a[0]=1;
	a[1]=2;
	a[2]=3;
	a[3]=4;
}

void loop()
{
	for(int i=0;i<3;i++)
	{
		int j=0;
	}
	for(int i=0;i<3;i++)
	{
		int j=1;
	}
}

void buffer()
{
	char buffer[64];
	buffer[0] = 'A';
	buffer[1] = 'B';
	buffer[2] = 'C';
}

void array()
{
	int array[5];
	for(int i=0;i<5;i++)
	{
		array[i]=i;
	}
}

void demo_stackframe(int a,int b,int c)
{
	int x = a;
	float y = 5.00;
	double z = 10.00;
	
	char *hello ="Hello World";
	bar(z,y);
}

int main ()
{
	a=1;
	b='a';
	return 0;
}