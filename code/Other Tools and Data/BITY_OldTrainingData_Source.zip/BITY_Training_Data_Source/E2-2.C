#include<stdio.h>
void func(unsigned u)
{
	int a,b,c,d;

	a=12;b=-24;
	c=a+u;d=b+u;
	printf("a+u=%d,b+u=%d\n",c,d);
}

int main(int argc, char *argv[])
{
	unsigned u=10;
	func(u);
	return 0;
}