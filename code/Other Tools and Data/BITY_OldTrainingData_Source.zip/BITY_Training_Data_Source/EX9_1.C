#include <stdio.h>
void func(	int *pointer_1,	int *pointer_2)
{
	int a,b;
	a=100;
	b=10;
	pointer_1=&a;
	pointer_2=&b;
	printf("%d %d\n",a,b);
	printf("%d %d\n",*pointer_1,*pointer_2);
}

int main(int argc, char *argv[])
{
	int *pointer_1;
	int *pointer_2;
	func(pointer_1, pointer_2);
	return 0;
}