long long int longlongint (long long int a, long long int b, long long int c, double d)
{
	c=a+b;
	b=a/c;
	d=c+b;
	return b;
}

int main()
{
	long long int a; 
	long long int b; 
	long long int c; 
	double d;
	longlongint (a,b,c,d);
	return 0;
}