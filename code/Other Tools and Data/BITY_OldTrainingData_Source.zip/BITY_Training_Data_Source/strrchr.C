char *strrchr (char *string, char ch)

{
             char *start = string;

             while (*string++)
                     ;
             while (--string != start && *string != ch)
                     ;
             if (*string == ch)
                     return(string);
             return(0);
}

int main()
{
	char* dst;
	char src;
	strrchr(dst,src);
}