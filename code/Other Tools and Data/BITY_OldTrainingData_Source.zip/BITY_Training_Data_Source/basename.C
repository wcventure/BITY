#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <libgen.h> 
#include <unistd.h>
 
void func(char *test_a,char *test_b,char *test_c) {

	printf("Test 1: '/usr/bin' -> %s \n", basename(test_a));
	printf("Test 2: '/sdcard/miui_recovery/backup/blobs' -> %s \n", basename(test_b));
	printf("Test 3: '/sdcard/update.zip' -> %s \n", basename(test_c));
    
 }


int main(int argc, char *argv[])
{
	char *test_a = "/usr/bin";
	char *test_b = "/sdcard/miui_recovery/backup/blobs";
	char *test_c = "/sdcard/update.zip";
	func(test_a,test_b,test_c);
	return 0;
}